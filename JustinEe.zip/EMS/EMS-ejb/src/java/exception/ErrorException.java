package error;

public class ErrorException extends Exception {

    public ErrorException() {
    }

    public ErrorException(String s) {
        super(s);
    }

}
