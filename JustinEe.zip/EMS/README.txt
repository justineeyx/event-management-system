Justin Ee
A0252158E
Database name: emsDB
Username:administrator
Password:password
Extra feature : Edit Event Details